package app.util;

import app.model.Event;
import app.model.RecurringEvent;

import java.io.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BackupManager {

    private static final String EVENT_FILE = "data/event.csv";
    private static final String RECURRENT_FILE = "data/recurrent.csv";

    public static void backup(String backupPath) {

        try (PrintWriter pw = new PrintWriter(new FileWriter(backupPath))) {

            pw.println("#EVENTS");
            copyFile(EVENT_FILE, pw);

            pw.println();
            pw.println("#RECURRENT");
            copyFile(RECURRENT_FILE, pw);

            System.out.println("Backup completed to " + backupPath);

        } catch (IOException e) {
            System.out.println("Backup failed.");
        }
    }

    private static void copyFile(String source, PrintWriter pw) {
        try (BufferedReader br = new BufferedReader(new FileReader(source))) {
            String line;
            while ((line = br.readLine()) != null) {
                pw.println(line);
            }
        } catch (IOException e) {
            pw.println(); // file may not exist yet
        }
    }

    public static void restore(String backupPath) {

        // Desired behavior:
        // - Don't overwrite any events that currently exist (e.g., newly added after backup)
        // - Bring back events from the backup, but assign them NEW IDs so they don't collide
        // - Update recurrent.csv entries to point to the new IDs

        List<Event> currentEvents = EventFileHandler.readEvents();
        int nextId = EventFileHandler.getNextEventId(currentEvents);

        List<Event> backupEvents = new ArrayList<>();
        List<RecurringEvent> backupRecurring = new ArrayList<>();

        enum Section { NONE, EVENTS, RECURRENT }
        Section section = Section.NONE;

        try (BufferedReader br = new BufferedReader(new FileReader(backupPath))) {
            String line;

            while ((line = br.readLine()) != null) {
                if (line.equals("#EVENTS")) {
                    section = Section.EVENTS;
                    continue;
                }
                if (line.equals("#RECURRENT")) {
                    section = Section.RECURRENT;
                    continue;
                }

                if (section == Section.NONE) {
                    continue;
                }

                if (line.trim().isEmpty()) {
                    continue;
                }

                // Skip CSV header rows
                if (line.startsWith("eventId,")) {
                    continue;
                }

                String[] parts = line.split(",");

                if (section == Section.EVENTS) {
                    if (parts.length < 5) {
                        continue;
                    }

                    int oldId = Integer.parseInt(parts[0]);
                    String title = parts[1];
                    String desc = parts[2];
                    LocalDateTime start = LocalDateTime.parse(parts[3]);
                    LocalDateTime end = LocalDateTime.parse(parts[4]);
                    backupEvents.add(new Event(oldId, title, desc, start, end));
                } else if (section == Section.RECURRENT) {
                    if (parts.length < 4) {
                        continue;
                    }

                    int oldId = Integer.parseInt(parts[0]);
                    String interval = parts[1];
                    int times = Integer.parseInt(parts[2]);
                    LocalDate endDate = parts[3].equals("0") ? null : LocalDate.parse(parts[3]);
                    backupRecurring.add(new RecurringEvent(oldId, interval, times, endDate));
                }
            }

        } catch (IOException | RuntimeException e) {
            System.out.println("Restore failed.");
            return;
        }

        // Build mapping from backup event IDs to newly assigned IDs.
        // Only create mapping entries for events we actually restore.
        Map<Integer, Integer> idMap = new HashMap<>();
        List<Event> mergedEvents = new ArrayList<>(currentEvents);

        for (Event be : backupEvents) {
            // Skip restore if this event would overlap anything that already exists.
            Event candidate = new Event(-1, be.getTitle(), be.getDescription(), be.getStartDateTime(), be.getEndDateTime());
            if (hasConflict(candidate, mergedEvents)) {
                continue;
            }

            int newId = nextId++;
            idMap.put(be.getEventId(), newId);
            mergedEvents.add(new Event(newId, be.getTitle(), be.getDescription(), be.getStartDateTime(), be.getEndDateTime()));
        }

        List<RecurringEvent> mergedRecurring = new ArrayList<>(RecurringFileHandler.readRecurringEvents());
        for (RecurringEvent brc : backupRecurring) {
            Integer newEventId = idMap.get(brc.getEventId());
            if (newEventId == null) {
                continue;
            }

            // Ensure we don't accidentally add duplicate recurring config for the same new ID.
            mergedRecurring.removeIf(r -> r.getEventId() == newEventId);
            mergedRecurring.add(new RecurringEvent(newEventId, brc.getInterval(), brc.getRecurrentTimes(), brc.getRecurrentEndDate()));
        }

        EventFileHandler.writeEvents(mergedEvents);
        RecurringFileHandler.writeRecurringEvents(mergedRecurring);

        System.out.println("Restore completed from " + backupPath);
    }

    private static boolean hasConflict(Event newEvent, List<Event> events) {
        for (Event e : events) {
            boolean overlap = newEvent.getStartDateTime().isBefore(e.getEndDateTime())
                    && newEvent.getEndDateTime().isAfter(e.getStartDateTime());

            if (overlap) {
                return true;
            }
        }
        return false;
    }

}
