package app.view;

import app.model.Event;
import app.model.RecurringEvent;
import app.util.RecurringFileHandler;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.List;

public class CalendarView {

    private static List<Event> withRecurringOccurrences(List<Event> events, LocalDate rangeStart, LocalDate rangeEnd) {
        // Generate additional Event objects for recurring rules within [rangeStart, rangeEnd]
        // without mutating the original list.
        List<Event> expanded = new ArrayList<>(events);

        List<RecurringEvent> recurringRules = RecurringFileHandler.readRecurringEvents();
        if (recurringRules.isEmpty()) {
            return expanded;
        }

        for (RecurringEvent rule : recurringRules) {
            Event base = null;
            for (Event e : events) {
                if (e.getEventId() == rule.getEventId()) {
                    base = e;
                    break;
                }
            }
            if (base == null) {
                continue;
            }

            int stepDays;
            String interval = rule.getInterval();
            if (interval == null) {
                continue;
            }

            interval = interval.trim().toLowerCase();
            if (interval.equals("1d")) {
                stepDays = 1;
            } else if (interval.equals("1w")) {
                stepDays = 7;
            } else {
                // Backward-compat: some files may store "1" meaning weekly.
                // If you want different semantics, adjust here.
                if (interval.equals("1")) {
                    stepDays = 7;
                } else {
                    continue;
                }
            }

            LocalDateTime start = base.getStartDateTime();
            LocalDateTime end = base.getEndDateTime();
            long durationMinutes = ChronoUnit.MINUTES.between(start, end);

            int maxOccurrences = rule.getRecurrentTimes();
            LocalDate endDateLimit = rule.getRecurrentEndDate();

            // Start from the NEXT occurrence (don't duplicate the base event itself)
            int generated = 0;
            int occurrenceIndex = 1;

            while (true) {
                if (maxOccurrences > 0 && generated >= maxOccurrences) {
                    break;
                }

                LocalDateTime occStart = start.plusDays((long) stepDays * occurrenceIndex);
                LocalDate occDate = occStart.toLocalDate();

                if (endDateLimit != null && occDate.isAfter(endDateLimit)) {
                    break;
                }

                if (occDate.isAfter(rangeEnd)) {
                    break;
                }

                if (!occDate.isBefore(rangeStart)) {
                    LocalDateTime occEnd = occStart.plusMinutes(durationMinutes);
                    // Use the same eventId so it shows as the same event series.
                    expanded.add(new Event(base.getEventId(), base.getTitle(), base.getDescription(), occStart, occEnd));
                    generated++;
                }

                occurrenceIndex++;
            }
        }

        return expanded;
    }

    // ========== MONTH VIEW ==========
    public static void showMonthView(List<Event> events, int year, int month) {

        YearMonth ym = YearMonth.of(year, month);
        LocalDate rangeStart = ym.atDay(1);
        LocalDate rangeEnd = ym.atEndOfMonth();
        List<Event> allEvents = withRecurringOccurrences(events, rangeStart, rangeEnd);
        LocalDate firstDay = ym.atDay(1);

        System.out.println("\n" + ym.getMonth() + " " + year);
        System.out.println("Su Mo Tu We Th Fr Sa");

        int startOffset = firstDay.getDayOfWeek().getValue() % 7;

        for (int i = 0; i < startOffset; i++) {
            System.out.print("   ");
        }

        for (int day = 1; day <= ym.lengthOfMonth(); day++) {
            LocalDate date = ym.atDay(day);

            boolean hasEvent = allEvents.stream()
                    .anyMatch(e -> e.getStartDateTime().toLocalDate().equals(date));

            System.out.printf("%2d%s ", day, hasEvent ? "*" : " ");

            if (date.getDayOfWeek() == DayOfWeek.SATURDAY) {
                System.out.println();
            }
        }
        System.out.println("\n");

        // Show event legend (one line per occurrence)
        for (Event e : allEvents) {
            if (e.getStartDateTime().getMonthValue() == month &&
                e.getStartDateTime().getYear() == year) {

                System.out.println("* " +
                        e.getStartDateTime().toLocalDate() + ": " +
                        e.getTitle() +
                        " (" + e.getStartDateTime().toLocalTime() + ")");
            }
        }
    }

    // ========== WEEK VIEW ==========
    public static void showWeekView(List<Event> events, LocalDate weekStart) {

        LocalDate rangeStart = weekStart;
        LocalDate rangeEnd = weekStart.plusDays(6);
        List<Event> allEvents = withRecurringOccurrences(events, rangeStart, rangeEnd);

        System.out.println("\n=== Week of " + weekStart + " ===");

        for (int i = 0; i < 7; i++) {
            LocalDate date = weekStart.plusDays(i);

            System.out.print(date.getDayOfWeek().toString().substring(0, 3)
                    + " " + date.getDayOfMonth() + ": ");

            boolean found = false;

            for (Event e : allEvents) {
                if (e.getStartDateTime().toLocalDate().equals(date)) {
                    System.out.print(e.getTitle() +
                            " (" + e.getStartDateTime().toLocalTime() + ")");
                    found = true;
                }
            }

            if (!found) {
                System.out.print("No events");
            }
            System.out.println();
        }
    }
}
