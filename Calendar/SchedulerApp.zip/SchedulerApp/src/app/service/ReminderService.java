package app.service;

import app.model.Event;
import app.model.RecurringEvent;
import app.model.Reminder;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

public class ReminderService {

    public static class NextReminderInfo {
        public final Event event;
        public final LocalDateTime occurrenceStart;
        public final LocalDateTime notifyAt;
        public final Duration timeUntilNotify;

        public NextReminderInfo(Event event, LocalDateTime occurrenceStart, LocalDateTime notifyAt, Duration timeUntilNotify) {
            this.event = event;
            this.occurrenceStart = occurrenceStart;
            this.notifyAt = notifyAt;
            this.timeUntilNotify = timeUntilNotify;
        }
    }

    public static Optional<NextReminderInfo> getNextUpcomingReminder(
            List<Event> events,
            List<RecurringEvent> recurringRules,
            List<Reminder> reminders,
            LocalDateTime now
    ) {
        if (events == null || reminders == null) {
            return Optional.empty();
        }

        Map<Integer, Reminder> reminderByEventId = new HashMap<>();
        for (Reminder r : reminders) {
            // If duplicates exist, keep the last one
            reminderByEventId.put(r.getEventId(), r);
        }

        // Quick lookup for recurring rules by eventId
        Map<Integer, RecurringEvent> recurringByEventId = new HashMap<>();
        if (recurringRules != null) {
            for (RecurringEvent re : recurringRules) {
                recurringByEventId.put(re.getEventId(), re);
            }
        }

        NextReminderInfo best = null;

        for (Event baseEvent : events) {
            Reminder reminder = reminderByEventId.get(baseEvent.getEventId());
            if (reminder == null) {
                continue;
            }

            LocalDateTime occurrenceStart = baseEvent.getStartDateTime();

            RecurringEvent rule = recurringByEventId.get(baseEvent.getEventId());
            if (rule != null) {
                occurrenceStart = nextOccurrenceStart(baseEvent.getStartDateTime(), rule, now);
                if (occurrenceStart == null) {
                    continue;
                }
            }

            LocalDateTime notifyAt = occurrenceStart.minusMinutes(reminder.getMinutesBefore());
            if (notifyAt.isBefore(now)) {
                // If notification time has already passed, we don't announce it at launch.
                continue;
            }

            Duration until = Duration.between(now, notifyAt);
            if (best == null || notifyAt.isBefore(best.notifyAt)) {
                best = new NextReminderInfo(baseEvent, occurrenceStart, notifyAt, until);
            }
        }

        return Optional.ofNullable(best);
    }

    private static LocalDateTime nextOccurrenceStart(LocalDateTime baseStart, RecurringEvent rule, LocalDateTime now) {
        String interval = rule.getInterval();
        if (interval == null) {
            return null;
        }

        interval = interval.trim().toLowerCase();

        // Support legacy "1" meaning weekly
        if (interval.equals("1")) {
            interval = "1w";
        }

        // Determine step
        int stepDays;
        if (interval.endsWith("d")) {
            stepDays = parseLeadingInt(interval, 1);
        } else if (interval.endsWith("w")) {
            stepDays = 7 * parseLeadingInt(interval, 1);
        } else {
            return null;
        }

        if (stepDays <= 0) {
            return null;
        }

        // Respect recurrence end date if present
        LocalDate endDate = rule.getRecurrentEndDate();

        // Respect recurrence count if present (>0). We'll search next occurrence and fail if exceeded.
        int maxTimes = 0;
        try {
            maxTimes = rule.getRecurrentTimes();
        } catch (Exception ignored) {
        }

        // Find the first occurrence start >= now (or strictly after now)
        // If baseStart already qualifies, use it.
        if (!baseStart.isBefore(now)) {
            if (endDate != null && baseStart.toLocalDate().isAfter(endDate)) {
                return null;
            }
            return baseStart;
        }

        long daysBetween = Duration.between(baseStart, now).toDays();
        long k = (daysBetween / stepDays);
        LocalDateTime candidate = baseStart.plusDays(k * stepDays);
        if (candidate.isBefore(now)) {
            candidate = candidate.plusDays(stepDays);
            k++;
        }

        // Now k is how many steps from base.
        if (maxTimes > 0) {
            // If maxTimes is N, occurrences are: 0..N-1
            if (k >= maxTimes) {
                return null;
            }
        }

        if (endDate != null && candidate.toLocalDate().isAfter(endDate)) {
            return null;
        }

        return candidate;
    }

    private static int parseLeadingInt(String interval, int defaultValue) {
        String num = interval.substring(0, interval.length() - 1).trim();
        if (num.isEmpty()) {
            return defaultValue;
        }
        try {
            return Integer.parseInt(num);
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }

    public static String formatDuration(Duration d) {
        if (d == null) {
            return "0 minutes";
        }
        long totalMinutes = Math.max(0, d.toMinutes());
        long days = totalMinutes / (60 * 24);
        long hours = (totalMinutes % (60 * 24)) / 60;
        long minutes = totalMinutes % 60;

        StringBuilder sb = new StringBuilder();
        if (days > 0) {
            sb.append(days).append(days == 1 ? " day" : " days");
        }
        if (hours > 0) {
            if (sb.length() > 0) sb.append(" ");
            sb.append(hours).append(hours == 1 ? " hour" : " hours");
        }
        if (minutes > 0 || sb.length() == 0) {
            if (sb.length() > 0) sb.append(" ");
            sb.append(minutes).append(minutes == 1 ? " minute" : " minutes");
        }
        return sb.toString();
    }
}
