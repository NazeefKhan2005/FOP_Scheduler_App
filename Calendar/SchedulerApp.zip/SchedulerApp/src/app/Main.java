package app;

import app.model.Event;
import app.model.RecurringEvent;
import app.model.Reminder;
import app.service.ReminderService;
import app.util.BackupManager;
import app.util.EventFileHandler;
import app.util.RecurringFileHandler;
import app.util.ReminderFileHandler;
import app.view.CalendarView;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Scanner;

public class Main {

    private static final Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {

        // Launch-time reminder notification
        showNextReminderAtLaunch();


        while (true) {
            showMenu();
            String input = sc.nextLine();

            if (input.isEmpty()) continue;

            int choice;
            try {
                choice = Integer.parseInt(input);
            } catch (NumberFormatException e) {
                System.out.println("Invalid choice.");
                continue;
            }

            switch (choice) {
                case 1 -> addEvent();
                case 2 -> updateEvent();
                case 3 -> deleteEvent();
                case 4 -> viewMonth();
                case 5 -> viewWeek();
                case 6 -> BackupManager.backup("backup.txt");
                case 7 -> BackupManager.restore("backup.txt");
                case 8 -> searchEvents();
                case 9 -> setReminder();
                case 0 -> {
                    System.out.println("Have a nice day!");
                    return;
                }
                default -> System.out.println("Invalid choice.");
            }
        }
    }

    private static void showMenu() {
        System.out.println("""
        \n==== Calendar App ====
        1. Add Event
        2. Update Event
        3. Delete Event
        4. View Month Calendar
        5. View Week Calendar
        6. Backup
        7. Restore
        8. Search Events
        9. Set Reminder
        0. Exit
                """);
        System.out.print("Choose: ");
    }

    private static void showNextReminderAtLaunch() {
        List<Event> events = EventFileHandler.readEvents();
        List<RecurringEvent> recurringRules = RecurringFileHandler.readRecurringEvents();
        List<Reminder> reminders = ReminderFileHandler.readReminders();

        ReminderService.getNextUpcomingReminder(events, recurringRules, reminders, LocalDateTime.now())
                .ifPresent(info -> {
                    String human = ReminderService.formatDuration(info.timeUntilNotify);
                    System.out.println("Your next event is coming soon in " + human + ": " + info.event.getTitle());
                });
    }

    private static void setReminder() {

        int eventId;
        try {
            System.out.print("Event ID to set reminder for: ");
            eventId = Integer.parseInt(sc.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Invalid event ID.");
            return;
        }

        List<Event> events = EventFileHandler.readEvents();
        boolean exists = events.stream().anyMatch(e -> e.getEventId() == eventId);
        if (!exists) {
            System.out.println("Event not found.");
            return;
        }

        int minutes;
        try {
            System.out.print("Remind how many minutes before the event? (example: 30, 1440 for 1 day): ");
            minutes = Integer.parseInt(sc.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Invalid number.");
            return;
        }

        if (minutes < 0) {
            System.out.println("Minutes cannot be negative.");
            return;
        }

        List<Reminder> reminders = ReminderFileHandler.readReminders();
        reminders.removeIf(r -> r.getEventId() == eventId);
        reminders.add(new Reminder(eventId, minutes));
        ReminderFileHandler.writeReminders(reminders);

        System.out.println("Reminder set for event " + eventId + " (" + minutes + " minutes before)");
    }

    // ================= ADD EVENT =================
    private static void addEvent() {

        List<Event> events = EventFileHandler.readEvents();
        int id = EventFileHandler.getNextEventId(events);

        System.out.print("Title: ");
        String title = sc.nextLine();

        System.out.print("Description: ");
        String desc = sc.nextLine();

        LocalDateTime start;
        LocalDateTime end;
        try {
            System.out.print("Start (yyyy-MM-ddTHH:mm): ");
            start = LocalDateTime.parse(sc.nextLine());

            System.out.print("End (yyyy-MM-ddTHH:mm): ");
            end = LocalDateTime.parse(sc.nextLine());
        } catch (Exception parseEx) {
            System.out.println("Invalid date/time format. Please use yyyy-MM-ddTHH:mm (example: 2026-01-06T10:30)");
            return;
        }

        Event e = new Event(id, title, desc, start, end);

        if (EventFileHandler.hasConflict(e)) {
            System.out.println("Time conflict detected. Event not added.");
            return;
        }

        events.add(e);
        EventFileHandler.writeEvents(events);

        // Optional: add recurring settings immediately after creating the event
    System.out.print("Is this event recurring? (y/n): ");
    String recurringAnswer = sc.nextLine().trim().toLowerCase();
        if (recurringAnswer.equals("y") || recurringAnswer.equals("yes")) {

            System.out.print("Interval (1d / 1w): ");
            String interval = sc.nextLine().trim();

            System.out.println("""
                    1. Repeat until end date
                    2. Repeat for number of times
                    """);
            int choice;
            try {
                System.out.print("Choose: ");
                choice = Integer.parseInt(sc.nextLine());
            } catch (NumberFormatException nfeChoice) {
                System.out.println("Invalid choice. Event was added as non-recurring.");
                System.out.println("Event added with ID " + id);
                return;
            }

            int times = 0;
            LocalDate endDate = null;

            if (choice == 1) {
                try {
                    System.out.print("End date (yyyy-MM-dd): ");
                    endDate = LocalDate.parse(sc.nextLine());
                } catch (Exception parseEndDateEx) {
                    System.out.println("Invalid date format. Event was added as non-recurring.");
                    System.out.println("Event added with ID " + id);
                    return;
                }
            } else if (choice == 2) {
                try {
                    System.out.print("Number of times: ");
                    times = Integer.parseInt(sc.nextLine());
                } catch (NumberFormatException nfeTimes) {
                    System.out.println("Invalid number. Event was added as non-recurring.");
                    System.out.println("Event added with ID " + id);
                    return;
                }
            } else {
                System.out.println("Invalid choice. Event was added as non-recurring.");
                System.out.println("Event added with ID " + id);
                return;
            }

            List<RecurringEvent> list = RecurringFileHandler.readRecurringEvents();
            // Ensure we don't end up with duplicate recurring entries for the same event.
            list.removeIf(r -> r.getEventId() == id);
            list.add(new RecurringEvent(id, interval, times, endDate));
            RecurringFileHandler.writeRecurringEvents(list);

            System.out.println("Event added with ID " + id + " (recurring)");
            return;
        }

        System.out.println("Event added with ID " + id);
    }

    // ================= UPDATE EVENT =================
    private static void updateEvent() {

        int id;
        try {
            System.out.print("Event ID to update: ");
            id = Integer.parseInt(sc.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Invalid event ID.");
            return;
        }

        System.out.print("New Title: ");
        String title = sc.nextLine();

        System.out.print("New Description: ");
        String desc = sc.nextLine();

        LocalDateTime start;
        LocalDateTime end;
        try {
            System.out.print("New Start (yyyy-MM-ddTHH:mm): ");
            start = LocalDateTime.parse(sc.nextLine());

            System.out.print("New End (yyyy-MM-ddTHH:mm): ");
            end = LocalDateTime.parse(sc.nextLine());
        } catch (Exception e) {
            System.out.println("Invalid date/time format. Please use yyyy-MM-ddTHH:mm (example: 2026-01-06T10:30)");
            return;
        }

        Event updated = new Event(id, title, desc, start, end);

        if (EventFileHandler.hasConflict(updated)) {
            System.out.println("Time conflict detected. Update cancelled.");
            return;
        }

        boolean ok = EventFileHandler.updateEvent(updated);
        System.out.println(ok ? "Event updated." : "Event not found.");
    }

    // ================= DELETE EVENT =================
    private static void deleteEvent() {

        int id;
        try {
            System.out.print("Event ID to delete: ");
            id = Integer.parseInt(sc.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Invalid event ID.");
            return;
        }

        boolean ok = EventFileHandler.deleteEvent(id);
        if (ok) {
            // Also remove any recurring settings tied to this event.
            List<RecurringEvent> recurring = RecurringFileHandler.readRecurringEvents();
            boolean removedRecurring = recurring.removeIf(r -> r.getEventId() == id);
            if (removedRecurring) {
                RecurringFileHandler.writeRecurringEvents(recurring);
            }

            System.out.println("Event deleted." + (removedRecurring ? " (Recurring entry removed.)" : ""));
        } else {
            System.out.println("Event not found.");
        }
    }

    // ================= VIEW MONTH =================
    private static void viewMonth() {

        int year;
        int month;
        try {
            System.out.print("Year: ");
            year = Integer.parseInt(sc.nextLine());

            System.out.print("Month (1-12): ");
            month = Integer.parseInt(sc.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Invalid year/month.");
            return;
        }

        List<Event> events = EventFileHandler.readEvents();
        CalendarView.showMonthView(events, year, month);
    }

    // ================= VIEW WEEK =================
    private static void viewWeek() {

        LocalDate start;
        try {
            System.out.print("Week start date (yyyy-MM-dd): ");
            start = LocalDate.parse(sc.nextLine());
        } catch (Exception e) {
            System.out.println("Invalid date format. Please use yyyy-MM-dd (example: 2026-01-06)");
            return;
        }

        List<Event> events = EventFileHandler.readEvents();
        CalendarView.showWeekView(events, start);
    }

    // ================= SEARCH =================
    private static void searchEvents() {

        System.out.println("""
                1. Search by date
                2. Search by date range
                """);
        int choice;
        try {
            System.out.print("Choose: ");
            choice = Integer.parseInt(sc.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Invalid choice.");
            return;
        }

        if (choice == 1) {
            try {
                System.out.print("Date (yyyy-MM-dd): ");
                LocalDate date = LocalDate.parse(sc.nextLine());
                displayResults(EventFileHandler.searchByDate(date));
            } catch (Exception e) {
                System.out.println("Invalid date format. Please use yyyy-MM-dd (example: 2026-01-06)");
            }

        } else if (choice == 2) {
            try {
                System.out.print("Start date (yyyy-MM-dd): ");
                LocalDate start = LocalDate.parse(sc.nextLine());

                System.out.print("End date (yyyy-MM-dd): ");
                LocalDate end = LocalDate.parse(sc.nextLine());

                displayResults(EventFileHandler.searchByDateRange(start, end));
            } catch (Exception e) {
                System.out.println("Invalid date format. Please use yyyy-MM-dd (example: 2026-01-06)");
            }
        } else {
            System.out.println("Invalid choice.");
        }
    }

    private static void displayResults(List<Event> events) {

        if (events.isEmpty()) {
            System.out.println("No events found.");
            return;
        }

        for (Event e : events) {
            System.out.println("[" + e.getEventId() + "] " + e.getTitle());
            System.out.println("    " + e.getStartDateTime() +
                    " → " + e.getEndDateTime());
            System.out.println();
        }
    }

}
